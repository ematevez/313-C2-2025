from setuptools import setup, find_packages

setup(
    name="Semana4",
    version="0.0.1",
    packages=find_packages(),
    install_requires=[],
)
